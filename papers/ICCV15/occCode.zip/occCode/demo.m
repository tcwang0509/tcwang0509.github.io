%% Input: 5D double array of size [h x w x 3 x v x u]
% [h w 3] is spatial image size, and [v u] is angular size
% read Wanner's data
hinfo_data = hdf5info('input/lf_mona.h5');
data = hdf5read(hinfo_data.GroupHierarchy.Datasets(2));
data = permute(data, [3 2 1 5 4]); 
data = im2double(data(:, :, :, :, end:-1:1));
% % read our data
% hinfo_data = hdf5info('input/livingroom.h5');
% data = double(hdf5read(hinfo_data.GroupHierarchy.Datasets(3)));

depth_output = computeDepth(data);
figure; imshow(depth_output);